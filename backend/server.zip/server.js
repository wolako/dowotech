const express = require('express');
const bodyParser = require('body-parser');
const mysql = require('mysql2/promise');
const cors = require('cors');

const app = express();
const port = 3000;

// Middleware pour activer CORS
app.use(cors());

// Configuration de la connexion à MySQL avec createPool()
const pool = mysql.createPool({
  host: 'dowotech.com',
  user: 'u525292028_dowo_admin',
  password: 'Mi@b2baz',
  database: 'u525292028_dowo_contact'
});

// Middleware pour parser les requêtes JSON
app.use(bodyParser.json());

// Endpoint pour ajouter un nouveau contact
app.post('/contacts', async (req, res) => {
  const { nom, prenom, phone, email, service, message } = req.body;
  try {
    // Obtenir une connexion à partir du pool
    const connection = await pool.getConnection();
    // Exécuter la requête SQL
    const [results, fields] = await connection.execute('INSERT INTO contacts (nom, prenom, phone, email, services, message) VALUES (?, ?, ?, ?, ?, ?)', [nom, prenom, email, phone, services, message]);
    // Libérer la connexion
    connection.release();
    // Envoyer une réponse au client
    res.status(201).json({ message: 'Contact enregistré avec succès' });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Erreur lors de l\'enregistrement du contact' });
  }
});

// Démarrage du serveur
app.listen(port, () => {
  console.log(`Serveur démarré sur le port ${port}`);
});
